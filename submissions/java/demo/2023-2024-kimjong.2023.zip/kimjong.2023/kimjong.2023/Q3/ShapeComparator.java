/*
 * Name: Kim Jong
 * Email ID: kimjong.2023
 */

import java.util.*;   

public class ShapeComparator{

    
}
