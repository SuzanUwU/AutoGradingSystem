/*
 * Name: Part Chan
 * Email ID: partchan.2023
 */

import java.util.*;   

public class ShapeComparator{

    
}
