/*
 * Name: Alicia Tay
 * Email ID: alicia.tay.2025
 */

import java.util.*;   

public class ShapeComparator implements Comparator<Shape>{

    public int compare(Shape o1, Shape o2) {
        if(o1.getArea() != o2.getArea()){
            if((o2.getArea() - o1.getArea())>0){
                return 1;
            }
            else{
                return -1;
            }
        }
        // bug: forgot the perimeter tie-breaker when areas are equal
        return 0;
    }

}
