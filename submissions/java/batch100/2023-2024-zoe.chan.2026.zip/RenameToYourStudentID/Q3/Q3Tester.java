public class Q3Tester { public static void main(String[] a){ System.out.println(4.0); } }
