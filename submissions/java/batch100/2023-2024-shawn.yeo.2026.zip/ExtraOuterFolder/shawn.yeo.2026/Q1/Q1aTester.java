public class Q1aTester { public static void main(String[] a){ System.out.println(3.0); } }
