# Name: Benjamin Lee
# Email ID: benjamin.lee.2026

def is_partially_compliant(table):
    # Replace the code below with your implementation.
    return None