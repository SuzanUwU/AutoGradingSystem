# Name: Benjamin Lee
# Email ID: benjamin.lee.2026

def compute_rebate(is_singaporean_household, flat_type, month):
    # Replace the code below with your implementation.
    return None