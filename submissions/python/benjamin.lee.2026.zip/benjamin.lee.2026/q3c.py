# Name: Benjamin Lee
# Email ID: benjamin.lee.2026


def make_tables_fully_compliant(t1, t2):
    # Replace the code below with your implementation.
    return None
    