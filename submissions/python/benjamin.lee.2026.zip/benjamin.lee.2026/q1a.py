# Name: Benjamin Lee
# Email ID: benjamin.lee.2026

def compute_parking(duration):
    # Replace the code below with your implementation.
    return None