# Name: Benjamin Lee
# Email ID: benjamin.lee.2026

def count_non_digits(str_list):
    # Modify the code below.
    return None