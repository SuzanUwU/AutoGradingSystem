# Name: Benjamin Lee
# Email ID: benjamin.lee.2026

def get_digits_of_even_index(my_str):
    # Modify the code below.
    return None