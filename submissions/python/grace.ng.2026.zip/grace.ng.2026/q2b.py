# Name: Grace Ng
# Email ID: grace.ng.2026

def count_non_digits(str_list):
    # Modify the code below.
    return None