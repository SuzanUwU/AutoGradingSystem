# Name: Grace Ng
# Email ID: grace.ng.2026

def get_digits_of_even_index(my_str):
    # Modify the code below.
    return None