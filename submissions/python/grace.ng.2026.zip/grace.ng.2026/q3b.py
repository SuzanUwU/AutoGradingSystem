# Name: Grace Ng
# Email ID: grace.ng.2026

from q3a import is_partially_compliant

def is_fully_compliant(table):
    # Replace the code below with your implementation.
    return None