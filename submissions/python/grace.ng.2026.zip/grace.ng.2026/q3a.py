# Name: Grace Ng
# Email ID: grace.ng.2026

def is_partially_compliant(table):
    # Replace the code below with your implementation.
    return None